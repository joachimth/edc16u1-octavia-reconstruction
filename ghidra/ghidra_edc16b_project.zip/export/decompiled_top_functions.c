// Top external-flash functions by xref count (r13=0x4017F0 applied)

// ==== FUN_00868350 @0x00868350  (170 xrefs) ====

undefined4 FUN_00868350(byte param_1,int param_2,byte param_3,int param_4,int param_5,int *param_6)

{
  int unaff_r14;
  int iVar1;
  int iVar2;
  byte bVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 uVar7;
  
  iVar5 = (uint)param_1 * 0xc;
  iVar1 = *(int *)(unaff_r14 + -0x1d3c);
  iVar4 = iVar1 + (uint)*(ushort *)(unaff_r14 + -0x1ed0 + iVar5) + param_2;
  bVar3 = *(byte *)(unaff_r14 + 0x4cda + ((int)(-(uint)param_3 & ~(uint)param_3) >> 0x1f) * -8 +
                    (uint)(param_6 != (int *)0x0) * 4 + (uint)(param_5 != 0) * 2 + param_4);
  if (bVar3 == 0) {
    return 0x81;
  }
  if (((bVar3 & 0x40) != 0) && ((*(ushort *)(unaff_r14 + -0x1ec8 + iVar5) >> 2 & 1) == 0)) {
    return 0x81;
  }
  if (((bVar3 & 0x20) == 0) && ((DAT_003ffb30 & 1) != 0)) {
    return 0x83;
  }
  if (((bVar3 & 0x10) != 0) &&
     (iVar2 = unaff_r14 + -0x1ed0 + iVar5, (*(ushort *)(iVar2 + 8) >> 7 & 1) != 0)) {
    func_0x0005a59c(param_5,*(int *)(unaff_r14 + -0x1d34) + (uint)*(ushort *)(iVar2 + 6),2);
  }
  bVar3 = bVar3 & 0xf;
  switch(bVar3) {
  case 0:
    return 0x81;
  case 1:
    func_0x00025d3c();
    iVar5 = unaff_r14 + -0x1ed0 + iVar5;
    if ((*(ushort *)(iVar5 + 8) & 3) != 0) {
      uVar6 = (uint)*(byte *)(iVar5 + 10);
      *(undefined1 *)(param_5 + uVar6 + -3) = *(undefined1 *)(iVar4 + uVar6 + -3);
    }
    (**(code **)(unaff_r14 + -0x1c8c))(param_1,param_5,iVar4);
    goto LAB_0086864c;
  case 2:
    func_0x00025d3c();
    iVar5 = unaff_r14 + -0x1ed0 + iVar5;
    func_0x0005a59c(param_5,iVar4,*(undefined1 *)(iVar5 + 10));
    func_0x00025d64();
    if ((*(ushort *)(iVar5 + 8) >> 5 & 1) == 0) {
      return 2;
    }
    iVar1 = (**(code **)(unaff_r14 + -0x1c94))(param_1,param_5);
    if (iVar1 == 0) {
      return 0x82;
    }
    return 2;
  case 3:
    break;
  case 4:
    break;
  case 5:
    break;
  case 6:
    func_0x00025d3c();
    FUN_0086731c(param_5,iVar4,param_3,
                 iVar1 + (uint)*(ushort *)(unaff_r14 + -0x1ed0 + iVar5) +
                 (uint)*(byte *)(unaff_r14 + -0x1ed0 + iVar5 + 10) + -2);
    goto LAB_0086864c;
  case 7:
    func_0x00025d3c();
    func_0x0005a59c(param_5,iVar4,param_3);
LAB_0086864c:
    func_0x00025d64();
    return 2;
  case 8:
    break;
  case 9:
    break;
  case 10:
    break;
  default:
    return 0x81;
  }
  iVar2 = unaff_r14 + -0x1ed0 + iVar5;
  if ((*(ushort *)(iVar2 + 8) >> 2 & 1) != 0) {
    if (bVar3 == 4) {
      func_0x00025d3c();
      if ((*(ushort *)(iVar2 + 8) & 3) != 0) {
        *(undefined1 *)(param_5 + (uint)*(byte *)(iVar2 + 10) + -3) =
             *(undefined1 *)(iVar4 + (uint)*(byte *)(iVar2 + 10) + -3);
      }
      (**(code **)(unaff_r14 + -0x1c8c))(param_1,param_5,iVar4);
    }
    else {
      if (bVar3 != 9) goto LAB_00868528;
      func_0x00025d3c();
      FUN_0086731c(param_5,iVar4,param_3,
                   iVar1 + (uint)*(ushort *)(unaff_r14 + -0x1ed0 + iVar5) +
                   (uint)*(byte *)(iVar2 + 10) + -2);
    }
    func_0x00025d64();
  }
LAB_00868528:
  *(byte *)(param_6 + 1) = param_1;
  *(char *)((int)param_6 + 5) = (char)param_2;
  *(byte *)((int)param_6 + 6) = param_3;
  *param_6 = param_5;
  *(byte *)((int)param_6 + 7) = bVar3;
  func_0x00025d3c();
  if ((&DAT_0040181c)[DAT_003fe0f1] == 0) {
    (&DAT_0040181c)[DAT_003fe0f1] = param_6;
    DAT_003fe0f1 = DAT_003fe0f1 + 1 & *(char *)(unaff_r14 + -0x1d2b) - 1U;
    uVar7 = 1;
    *(undefined1 *)(param_6 + 2) = 1;
  }
  else {
    uVar7 = 0x40;
  }
  func_0x00025d64();
  if (DAT_003fffd4 == 2) {
    while (DAT_003fe6c8 != '!') {
      FUN_00867dd0();
    }
    DAT_003fe6c8 = ' ';
  }
  return uVar7;
}


// ==== FUN_008669ec @0x008669ec  (42 xrefs) ====

undefined1 FUN_008669ec(uint param_1,undefined1 *param_2,undefined1 *param_3)

{
  uint uVar1;
  
  *param_3 = *param_2;
  param_3[1] = 1;
  if (param_2[1] == '\x01') {
    if ((DAT_003fcf96 != '\0') && (param_1 != 0xff)) {
      uVar1 = 0;
      do {
        if ((byte)(&DAT_003fcf96)[uVar1 * 2] == param_1) {
          *param_3 = (&DAT_003fcf97)[uVar1 * 2];
          goto LAB_00866a5c;
        }
        uVar1 = uVar1 + 1 & 0xff;
      } while (uVar1 < 6);
    }
  }
  else {
LAB_00866a5c:
    param_3[1] = 0;
  }
  return param_3[1];
}


// ==== FUN_008611d4 @0x008611d4  (22 xrefs) ====

void FUN_008611d4(byte *param_1,int param_2)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  byte bVar5;
  byte bVar6;
  int iVar7;
  uint uVar8;
  byte bVar9;
  int unaff_r14;
  int iVar10;
  int iVar11;
  uint uVar12;
  
  iVar11 = 1;
  iVar10 = unaff_r14 + -0x1292;
  while( true ) {
    uVar12 = 0x80;
    do {
      bVar1 = *param_1;
      bVar2 = param_1[1];
      bVar3 = param_1[3];
      bVar4 = param_1[2];
      bVar5 = param_1[5];
      bVar9 = *(byte *)(param_2 + iVar11);
      if (*(char *)(unaff_r14 + -0x1282 +
                   (*(byte *)(unaff_r14 + -0x12a2 +
                             ((((uint)((bVar1 & 2) == 0) * -2 + 2 | (uint)((bVar1 & 4) != 0)) * 2 |
                              (uint)((bVar1 & 0x10) != 0)) * 2 & 0xff | (uint)((bVar1 & 0x20) != 0))
                             ) & 1 |
                    *(byte *)(iVar10 + ((((uint)((bVar2 & 1) == 0) * -2 + 2 |
                                         (uint)((bVar2 & 2) != 0)) * 2 | (uint)((bVar2 & 8) != 0)) *
                                        2 & 0xff | (uint)((bVar2 & 0x80) != 0))) & 2 |
                    *(byte *)(iVar10 + ((((uint)((bVar3 & 0x20) == 0) * -2 + 2 |
                                         (uint)((bVar4 & 1) != 0)) * 2 | (uint)((bVar4 & 4) != 0)) *
                                        2 & 0xff | (uint)((bVar4 & 0x40) != 0))) & 4 |
                    *(byte *)(iVar10 + ((((uint)((param_1[4] & 0x40) == 0) * -2 + 2 |
                                         (uint)((bVar3 & 1) != 0)) * 2 | (uint)((bVar3 & 4) != 0)) *
                                        2 & 0xff | (uint)((bVar3 & 8) != 0))) & 8 |
                   *(byte *)(unaff_r14 + -0x12a2 +
                            ((((uint)((bVar5 & 2) == 0) * -2 + 2 | (uint)((bVar5 & 8) != 0)) * 2 |
                             (uint)((bVar5 & 0x10) != 0)) * 2 & 0xff |
                            (uint)((param_1[4] & 0x20) != 0))) & 0x10)) == '\0') {
        bVar9 = bVar9 & ~(byte)uVar12;
      }
      else {
        bVar9 = (byte)uVar12 | bVar9;
      }
      *(byte *)(param_2 + iVar11) = bVar9;
      bVar1 = param_1[4];
      bVar2 = param_1[5];
      bVar3 = param_1[1];
      bVar4 = param_1[2];
      bVar5 = param_1[3];
      uVar8 = bVar1 & 0xde ^ bVar2 & 0xd0 ^ *param_1 & 0x24 ^ bVar3 & 0x27 ^ bVar4 & 0x72 ^
              bVar5 & 0x13;
      iVar7 = (int)uVar8 >> 4;
      bVar9 = *(byte *)(unaff_r14 + -0x12b2 + uVar8 + iVar7 * -0x10);
      bVar6 = *(byte *)(unaff_r14 + -0x12b2 + iVar7);
      param_1[1] = bVar3 * '\x02' | 1U - ((bVar4 & 0x80) == 0);
      param_1[2] = bVar4 * '\x02' | 1U - ((bVar5 & 0x80) == 0);
      uVar12 = uVar12 >> 1;
      param_1[3] = bVar5 * '\x02' | 1U - ((bVar1 & 0x80) == 0);
      *param_1 = *param_1 * '\x02' | 1U - ((bVar3 & 0x80) == 0);
      param_1[4] = bVar1 * '\x02' | 1U - ((bVar2 & 0x80) == 0);
      param_1[5] = bVar9 ^ bVar6 | bVar2 * '\x02';
    } while (uVar12 != 0);
    if (iVar11 == 0) break;
    iVar11 = 0;
  }
  return;
}


// ==== FUN_00802a24 @0x00802a24  (19 xrefs) ====

uint FUN_00802a24(byte *param_1)

{
  byte bVar1;
  uint uVar2;
  
  bVar1 = param_1[1] >> 4;
  if (bVar1 == 1) {
    uVar2 = 1;
LAB_00802a54:
    if (bVar1 == 4) {
      uVar2 = uVar2 | 4;
      goto LAB_00802a80;
    }
  }
  else {
    uVar2 = 0;
    if (bVar1 != 2) goto LAB_00802a54;
    uVar2 = 2;
  }
  if (bVar1 == 8) {
    uVar2 = uVar2 | 8;
  }
LAB_00802a80:
  if ((char)*param_1 < '\0') {
    uVar2 = uVar2 | 0x10;
  }
  if ((*param_1 >> 6 & 1) != 0) {
    uVar2 = uVar2 | 0x20;
  }
  if ((*param_1 >> 1 & 1) != 0) {
    uVar2 = uVar2 | 0x40;
  }
  if ((param_1[1] >> 3 & 1) != 0) {
    uVar2 = uVar2 | 0x80;
  }
  return uVar2;
}


// ==== FUN_0086eaf8 @0x0086eaf8  (16 xrefs) ====

int FUN_0086eaf8(char *param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
                undefined4 param_6,short *param_7,undefined4 param_8)

{
  byte bVar2;
  byte bVar3;
  undefined2 uVar1;
  ushort uVar4;
  int iVar5;
  undefined2 local_38 [2];
  undefined4 local_34;
  undefined1 local_30;
  undefined1 local_2f;
  undefined2 local_2c;
  undefined2 local_2a;
  undefined2 local_28;
  ushort local_26;
  
  local_2f = 0;
  local_34 = func_0x00042050(*(undefined2 *)(param_1 + 4));
  if (*param_1 == '\0') {
    func_0x0005abd0(param_1[1],param_3,param_1 + 0xe,param_2 + 9);
    if ((param_1[0x12] & 1U) == 0) {
      bVar2 = *(byte *)(param_2 + 8);
      *(byte *)(param_2 + 8) = bVar2 | 4;
      local_30 = 2;
      local_34 = CONCAT31(CONCAT21(local_34._0_2_,bVar2),(byte)param_1[0x12] >> 1) & 0xffffff01 |
                 0x400;
      bVar3 = func_0x00041790(param_2,&local_34,param_4);
      local_30 = 1;
      local_34 = CONCAT31(local_34._0_3_,(byte)param_1[0x12] >> 2) & 0xffffff01;
      bVar2 = func_0x00041790(param_2 + 2,&local_34,param_5);
      bVar2 = bVar2 | bVar3;
      uVar1 = *(undefined2 *)(param_1 + 0xe);
    }
    else {
      bVar2 = 1;
      uVar1 = *(undefined2 *)(param_2 + 6);
      func_0x00041d4c(param_2);
      func_0x00041d4c(param_2 + 2);
    }
  }
  else {
    bVar2 = param_1[6];
    if ((bVar2 & 0xe) == 0) {
      bVar3 = *(byte *)(param_2 + 8);
      *(byte *)(param_2 + 8) = bVar3 | 3;
      local_34._0_2_ = (undefined2)(local_34 >> 0x10);
      local_30 = 4;
      local_34 = CONCAT31(CONCAT21(local_34._0_2_,bVar3),bVar2) & 0xffffff01 | 0x300;
      bVar2 = func_0x00041790(param_2,&local_34,param_6);
    }
    else {
      func_0x00041d4c(param_2);
      if ((bVar2 >> 2 & 1) == 0) {
        bVar2 = 1;
      }
      else {
        bVar2 = 2;
      }
    }
    uVar1 = *(undefined2 *)(param_1 + 0xc);
    param_1[0xe] = '\0';
    param_1[0xf] = '\0';
    param_1[0x10] = '\0';
    param_1[0x11] = '\0';
    param_1[0x12] = '\0';
  }
  *(undefined1 *)(param_2 + 8) = local_34._2_1_;
  if ((bVar2 == 0) || (*param_7 == 0)) {
    iVar5 = 0;
  }
  else {
    iVar5 = 1;
  }
  local_34 = CONCAT13((byte)(iVar5 << 1) | local_34._0_1_ & 0xfd,local_34._1_3_);
  local_38[0] = local_34._0_2_;
  func_0x00041d58(*(undefined2 *)(param_1 + 4),local_38);
  local_26 = *(ushort *)(param_2 + 4) & 0xfff8;
  if (bVar2 != 0) {
    if ((bVar2 & 2) == 0) {
      if ((bVar2 & 4) != 0) {
        local_26 = local_26 | 4;
        goto LAB_0086ece8;
      }
      uVar4 = 2;
    }
    else {
      uVar4 = 1;
    }
    local_26 = local_26 | uVar4;
  }
LAB_0086ece8:
  local_2a = *(undefined2 *)(param_2 + 6);
  local_2c = uVar1;
  local_28 = uVar1;
  uVar1 = func_0x0005a3a0(param_7,param_8,&local_2c,*(undefined4 *)(param_1 + 8));
  *(undefined2 *)(param_1 + 2) = uVar1;
  *(undefined2 *)(param_2 + 6) = local_2a;
  *(ushort *)(param_2 + 4) = local_26;
  return (int)*(short *)(param_1 + 2);
}


// ==== FUN_0086e924 @0x0086e924  (11 xrefs) ====

void FUN_0086e924(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined2 *param_4,
                 undefined2 *param_5,undefined2 *param_6,byte *param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined2 *param_12,
                 short *param_13,undefined4 param_14,undefined2 param_15,undefined4 param_16)

{
  undefined4 uVar1;
  byte bVar3;
  byte bVar4;
  undefined2 uVar2;
  int iVar5;
  ushort uVar6;
  ushort uVar7;
  undefined2 local_50 [2];
  undefined2 local_4c;
  undefined2 local_4a;
  byte local_48;
  
  uVar1 = func_0x00042050(param_15);
  *(undefined4 *)param_7 = uVar1;
  func_0x0005abd0(param_1,param_2,&local_4c,param_3);
  *param_5 = local_4c;
  *param_6 = local_4a;
  if ((local_48 & 1) == 0) {
    param_7[3] = local_48 >> 1 & 1;
    param_7[4] = 2;
    bVar3 = func_0x00041790(param_8,param_7,param_10);
    param_7[3] = local_48 >> 2 & 1;
    param_7[4] = 1;
    bVar4 = func_0x00041790(param_9,param_7,param_11);
    bVar4 = bVar4 | bVar3;
  }
  else {
    bVar4 = 1;
    if (param_12 != (undefined2 *)0x0) {
      local_4c = param_12[1];
    }
    func_0x00041d4c(param_8);
    func_0x00041d4c(param_9);
  }
  if (param_12 == (undefined2 *)0x0) {
    uVar2 = *param_5;
    goto LAB_0086eaa0;
  }
  uVar7 = param_12[3] & 0xfff8;
  param_12[3] = uVar7;
  if ((bVar4 & 2) == 0) {
    if ((bVar4 & 4) != 0) {
      uVar7 = uVar7 | 4;
      goto LAB_0086ea74;
    }
    if ((bVar4 & 1) != 0) {
      uVar6 = 2;
      goto LAB_0086ea70;
    }
  }
  else {
    uVar6 = 1;
LAB_0086ea70:
    uVar7 = uVar7 | uVar6;
LAB_0086ea74:
    param_12[3] = uVar7;
  }
  *param_12 = local_4c;
  param_12[2] = local_4c;
  uVar2 = func_0x0005a3a0(param_13,param_14,param_12,param_16);
LAB_0086eaa0:
  *param_4 = uVar2;
  if ((bVar4 == 0) || (*param_13 == 0)) {
    iVar5 = 0;
  }
  else {
    iVar5 = 1;
  }
  *param_7 = (byte)(iVar5 << 1) | *param_7 & 0xfd;
  local_50[0] = *(undefined2 *)param_7;
  func_0x00041d58(param_15,local_50);
  return;
}


// ==== FUN_00854da8 @0x00854da8  (10 xrefs) ====

void FUN_00854da8(void)

{
  if ((DAT_003f9c70 == 0) || (DAT_003f9c54 == 0)) {
    DAT_003f9e96 = 1;
    DAT_003f9c4c = 4;
    DAT_003f9c5c = 0;
  }
  else {
    DAT_003f9c4c = 5;
    DAT_003f9c74 = 0;
    DAT_003fff99 = 0;
    DAT_003fff90 = DAT_003f9c54;
    DAT_003fd8a4 = DAT_003f9c54;
    DAT_003fd8a8 = 0;
    DAT_003fd8aa = 0;
    DAT_003f9e98 = 0;
    func_0x00024c7c(*DAT_003f9c3c,&DAT_003fd8ac,1);
  }
  return;
}


// ==== FUN_008592f4 @0x008592f4  (10 xrefs) ====

uint FUN_008592f4(int param_1,uint param_2,uint param_3)

{
  undefined1 *puVar1;
  uint uVar2;
  int iVar3;
  
  uVar2 = 0;
  if (param_3 != 0) {
    puVar1 = (undefined1 *)(param_1 + -1);
    do {
      iVar3 = uVar2 + 1;
      uVar2 = uVar2 + 1;
      puVar1 = puVar1 + 1;
      *puVar1 = (char)(param_2 >> ((param_3 - iVar3) * 8 & 0x38));
    } while (uVar2 < param_3);
  }
  return param_3 & 0xff;
}

