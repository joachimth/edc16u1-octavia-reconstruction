// Decompiled functions that reference the named calibration maps
