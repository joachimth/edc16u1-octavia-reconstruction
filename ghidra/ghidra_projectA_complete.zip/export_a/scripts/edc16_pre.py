# preScript: memory map + r13 + seed PPC function prologues (runs BEFORE auto-analysis)
#@category EDC16
from ghidra.program.model.address import AddressSet
from java.math import BigInteger

mem=currentProgram.getMemory()
sp=currentProgram.getAddressFactory().getDefaultAddressSpace()
def A(x): return sp.getAddress(x)

# relocate the raw image from 0x0 (BinaryLoader default) to CPU base 0x800000
BASE=0x800000
try:
    if currentProgram.getImageBase().getOffset()!=BASE:
        currentProgram.setImageBase(A(BASE), True)
        print("[pre] image base set to 0x%X"%BASE)
except Exception as e:
    print("[pre] setImageBase failed:",e)

def mkblk(name,start,length,vol=False):
    try:
        b=mem.createUninitializedBlock(name,A(start),length,False)
        b.setRead(True);b.setWrite(True);b.setExecute(False);b.setVolatile(vol)
        print("  block %s @0x%X (0x%X)"%(name,start,length))
    except Exception as e:
        print("  skip %s: %s"%(name,e))

print("[pre] memory blocks")
mkblk("sram_3F9800",0x3F9800,0x6800)
mkblk("ram_400000",0x400000,0x8000)
mkblk("extram_4FE000",0x4FE000,0x2000)
mkblk("usiu_2FC000",0x2FC000,0x880,True)
mkblk("imb3_300000",0x300000,0x8000,True)

print("[pre] set r13 = 0x4017F0")
try:
    r13=currentProgram.getRegister("r13")
    ctx=currentProgram.getProgramContext()
    whole=AddressSet(mem)
    ctx.setValue(r13, whole.getMinAddress(), whole.getMaxAddress(), BigInteger.valueOf(0x4017F0))
except Exception as e:
    print("  r13 failed:",e)

# seed disassembly: scan code regions for PPC prologue 'stwu r1,-X(r1)' = 0x9421 8xxx..ffff
print("[pre] scanning for PPC function prologues (stwu r1,-X(r1))")
from ghidra.program.model.mem import MemoryAccessException
def scan(start,end):
    seeds=[]
    a=start
    buf=bytearray(mem.getBytes(A(start), end-start))
    i=0
    n=end-start
    while i+4<=n:
        if buf[i]==0x94 and buf[i+1]==0x21 and (buf[i+2]&0x80):
            seeds.append(start+i)
            i+=4
        else:
            i+=4
    return seeds
seeds=[]
for s,e in [(0x800058,0x870000),(0x880060,0x8D0000)]:
    try: seeds+=scan(s,e)
    except Exception as ex: print("  scan err",ex)
print("  prologue candidates:",len(seeds))
# disassemble + create functions at seeds
from ghidra.app.cmd.disassemble import DisassembleCommand
from ghidra.app.cmd.function import CreateFunctionCmd
made=0
for addr in seeds:
    ad=A(addr)
    try:
        DisassembleCommand(ad, None, True).applyTo(currentProgram, monitor)
        if CreateFunctionCmd(ad).applyTo(currentProgram, monitor): made+=1
    except Exception:
        pass
print("  functions seeded:",made)
