#@category EDC16
import json
sp=currentProgram.getAddressFactory().getDefaultAddressSpace()
fm=currentProgram.getFunctionManager(); li=currentProgram.getListing()
OUT="/tmp/claude-0/-home-claude/c41a0a5e-ea8d-5325-97cf-9e69a91b4034/scratchpad/fw/out"
maps=json.load(open(OUT+"/maps_extracted.json"))
named=[m for m in maps if m['name']]
from collections import defaultdict
scal=defaultdict(set)
it=li.getInstructions(True); cnt=0
while it.hasNext():
    ins=it.next(); cnt+=1
    fn=fm.getFunctionContaining(ins.getAddress())
    fe=fn.getEntryPoint().getOffset() if fn else None
    if fe is None: continue
    for i in range(ins.getNumOperands()):
        for obj in ins.getOpObjects(i):
            try: v=obj.getValue()
            except: continue
            scal[v & 0xffff].add(fe)
anchors=[0x8D0000,0x8E0000,0x8F0000,0x8C0000]
with open(OUT+"/map_reader_candidates.csv","w") as f:
    f.write("name,data_cpu,disps_tried,candidate_reader_funcs,n\n")
    for m in named:
        cpu=int(m['data_cpu'],16); hdr=int(m.get('header_cpu','0x%X'%cpu),16)
        cands=set(); disps=[]
        for target in (hdr,cpu):
            for b in anchors:
                dsp=target-b
                if -0x8000<=dsp<0x8000:
                    disps.append('%X%+d'%(b,dsp))
                    for fe in scal.get(dsp & 0xffff,()): cands.add(fe)
        f.write('%s,%s,%s,%s,%d\n'%(m['name'],m['data_cpu'],';'.join(disps),
                ';'.join('0x%06X'%c for c in sorted(cands)[:10]),len(cands)))
print("instructions scanned:",cnt,"READERS DONE")
