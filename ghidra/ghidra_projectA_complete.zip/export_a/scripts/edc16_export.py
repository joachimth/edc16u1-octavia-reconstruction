# standalone export + map labeling against the already-analyzed program
#@category EDC16
import csv,os
from ghidra.program.model.symbol import SourceType
from ghidra.app.decompiler import DecompInterface
from ghidra.util.task import ConsoleTaskMonitor

OUT="/tmp/claude-0/-home-claude/c41a0a5e-ea8d-5325-97cf-9e69a91b4034/scratchpad/ghidra/export"
MAPCSV="/tmp/claude-0/-home-claude/c41a0a5e-ea8d-5325-97cf-9e69a91b4034/scratchpad/fw/out/named_maps_369564.csv"
try: os.makedirs(OUT)
except: pass

sp=currentProgram.getAddressFactory().getDefaultAddressSpace()
def A(x): return sp.getAddress(x)
st=currentProgram.getSymbolTable()
fm=currentProgram.getFunctionManager()
rm=currentProgram.getReferenceManager()
listing=currentProgram.getListing()

# 1) label named maps
mapaddrs=[]
labeled=0
if os.path.exists(MAPCSV):
    for row in csv.DictReader(open(MAPCSV)):
        try:
            cpu=int(row["cpu_addr"],16); nx=int(row["cols"]); ny=int(row["rows"])
            nm=(row.get("tuner_name") or "").strip()
            dims="%dx%d"%(nx,ny)
            label=("MAP_%s_%s"%(nm.replace(' ','_').replace('-','_'),dims)) if nm else ("MAP_%s_%06X"%(dims,cpu))
            st.createLabel(A(cpu),label,SourceType.USER_DEFINED)
            labeled+=1; mapaddrs.append((cpu,label,nm))
        except Exception as e:
            pass

# 2) functions export
funcs=[]
for fn in fm.getFunctions(True):
    e=fn.getEntryPoint()
    funcs.append((e.getOffset(), fn.getName(), fn.getBody().getNumAddresses(), rm.getReferenceCountTo(e)))
with open(OUT+"/functions.csv","w") as f:
    f.write("entry_cpu,name,size_bytes,xrefs_to\n")
    for off,nm,sz,xr in sorted(funcs):
        f.write("0x%06X,%s,%d,%d\n"%(off,nm,sz,xr))

# 3) xrefs to each labeled map (which function reads it)
with open(OUT+"/map_xrefs.csv","w") as f:
    f.write("map_cpu,label,tuner_name,xref_from,from_func\n")
    hit=0
    for cpu,label,nm in mapaddrs:
        for r in rm.getReferencesTo(A(cpu)):
            fa=r.getFromAddress(); fn=fm.getFunctionContaining(fa)
            f.write("0x%06X,%s,%s,0x%s,%s\n"%(cpu,label,nm,fa,fn.getName() if fn else ""))
            hit+=1

# 4) decompile the functions that reference the named (tuner) maps
named_map_addrs=[A(c) for c,l,nm in mapaddrs if nm]
decomp_targets=set()
for a in named_map_addrs:
    for r in rm.getReferencesTo(a):
        fn=fm.getFunctionContaining(r.getFromAddress())
        if fn: decomp_targets.add(fn.getEntryPoint())
di=DecompInterface(); di.openProgram(currentProgram); mon=ConsoleTaskMonitor()
with open(OUT+"/decompiled_map_readers.c","w") as f:
    f.write("// Decompiled functions that reference the named calibration maps\n")
    cnt=0
    for ep in list(decomp_targets)[:12]:
        fn=fm.getFunctionAt(ep)
        try:
            res=di.decompileFunction(fn,60,mon)
            if res and res.decompileCompleted():
                f.write("\n// ==== %s @0x%s ====\n"%(fn.getName(),ep))
                f.write(res.getDecompiledFunction().getC()); cnt+=1
        except Exception as e:
            pass
    decompiled=cnt

with open(OUT+"/summary.txt","w") as f:
    f.write("instructions: %d\n"%listing.getNumInstructions())
    f.write("defined functions: %d\n"%len(funcs))
    f.write("labeled maps: %d\n"%labeled)
    f.write("named-map reader functions decompiled: %d\n"%decompiled)
print("EXPORT DONE funcs=%d labeled=%d decompiled=%d instr=%d"%(len(funcs),labeled,decompiled,listing.getNumInstructions()))
