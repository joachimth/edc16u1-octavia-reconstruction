#@category EDC16
import struct,csv,os
from ghidra.program.model.data import PointerDataType
from ghidra.program.model.symbol import SourceType
from ghidra.app.decompiler import DecompInterface
from ghidra.util.task import ConsoleTaskMonitor
OUT="/tmp/claude-0/-home-claude/c41a0a5e-ea8d-5325-97cf-9e69a91b4034/scratchpad/ghidra/export"
MAPCSV="/tmp/claude-0/-home-claude/c41a0a5e-ea8d-5325-97cf-9e69a91b4034/scratchpad/fw/out/named_maps_369564.csv"
sp=currentProgram.getAddressFactory().getDefaultAddressSpace()
def A(x): return sp.getAddress(x)
mem=currentProgram.getMemory(); listing=currentProgram.getListing()
rm=currentProgram.getReferenceManager(); fm=currentProgram.getFunctionManager()

def rd32(off):
    b=mem.getByte(A(off))&0xff
    return (b<<24)|((mem.getByte(A(off+1))&0xff)<<16)|((mem.getByte(A(off+2))&0xff)<<8)|(mem.getByte(A(off+3))&0xff)

# define pointer table slots wherever consecutive dwords look like 0x008xxxxx (flash window)
pd=PointerDataType()
tbl=[]
for base in (0x800058,0x880058,0x8D0058):
    off=base; run=0
    while off < base+0x8000:
        try: v=rd32(off)
        except: break
        if 0x800000<=v<0x900000:
            tbl.append((off,v)); run+=1; off+=4
        else:
            off+=4
            if run>8: run=0
print("pointer-table slots (0x008xxxxx):",len(tbl))

# load labeled map addrs
maps={}
if os.path.exists(MAPCSV):
    for r in csv.DictReader(open(MAPCSV)):
        maps[int(r["cpu_addr"],16)]=(r.get("tuner_name") or "").strip()+(" %sx%s"%(r["cols"],r["rows"]))
mapset=sorted(maps)

# match each pointer value to nearest map start (slot points at header; data = header+4+axes...) tolerate 0..64 before
import bisect
def nearest_map(v):
    i=bisect.bisect_right(mapset,v)
    best=None
    for j in (i-1,i):
        if 0<=j<len(mapset):
            d=v-mapset[j]
            if -8<=d<=8 and (best is None or abs(d)<abs(best[1])): best=(mapset[j],d)
    return best

with open(OUT+"/pointer_table.csv","w") as f:
    f.write("slot_cpu,points_to,matched_map,delta,map_name\n")
    m=0
    for off,v in tbl:
        nm=nearest_map(v)
        if nm: f.write("0x%06X,0x%06X,0x%06X,%d,%s\n"%(off,v,nm[0],nm[1],maps[nm[0]])); m+=1
        else:  f.write("0x%06X,0x%06X,,,\n"%(off,v))
    print("slots matching a labeled map (+/-8B):",m)

# decompile top functions by xref count (the workhorses) as evidence of clean analysis
funcs=sorted(((rm.getReferenceCountTo(fn.getEntryPoint()),fn) for fn in fm.getFunctions(True)),key=lambda t:-t[0])
di=DecompInterface(); di.openProgram(currentProgram); mon=ConsoleTaskMonitor()
with open(OUT+"/decompiled_top_functions.c","w") as f:
    f.write("// Top external-flash functions by xref count (r13=0x4017F0 applied)\n")
    for xr,fn in funcs[:8]:
        try:
            res=di.decompileFunction(fn,60,mon)
            if res and res.decompileCompleted():
                f.write("\n// ==== %s @0x%s  (%d xrefs) ====\n"%(fn.getName(),fn.getEntryPoint(),xr))
                f.write(res.getDecompiledFunction().getC())
        except Exception as e: pass
print("PTR DONE")
