# postScript: label named maps from CSV, export symbols/functions/xrefs (runs AFTER analysis)
#@category EDC16
import csv,os
from ghidra.program.model.symbol import SourceType
from ghidra.program.model.data import UnsignedShortDataType, ArrayDataType

sp=currentProgram.getAddressFactory().getDefaultAddressSpace()
def A(x): return sp.getAddress(x)
st=currentProgram.getSymbolTable()
fm=currentProgram.getFunctionManager()
listing=currentProgram.getListing()

csvpath=os.environ.get("MAPCSV","")
labeled=0; mapaddrs=[]
if csvpath and os.path.exists(csvpath):
    print("[post] labeling maps from",csvpath)
    for row in csv.DictReader(open(csvpath)):
        try:
            cpu=int(row["cpu_addr"],16); nx=int(row["cols"]); ny=int(row["rows"])
            nm=row.get("tuner_name") or ""
            dims="%dx%d"%(nx,ny)
            label=("MAP_%s_%s"%(nm.replace(' ','_'),dims)) if nm else ("MAP_%s_%06X"%(dims,cpu))
            st.createLabel(A(cpu), label, SourceType.USER_DEFINED)
            labeled+=1; mapaddrs.append((cpu,label))
        except Exception as e:
            pass
print("[post] labeled maps:",labeled)

# exports
out=os.environ.get("EXPORT","/tmp/export")
# functions
with open(out+"/functions.csv","w") as f:
    f.write("entry,name,size,xref_count\n")
    cnt=0
    for fn in fm.getFunctions(True):
        e=fn.getEntryPoint()
        refs=currentProgram.getReferenceManager().getReferenceCountTo(e)
        f.write("0x%s,%s,%d,%d\n"%(e, fn.getName(), fn.getBody().getNumAddresses(), refs))
        cnt+=1
print("[post] functions exported:",cnt)

# xrefs to each map
with open(out+"/map_xrefs.csv","w") as f:
    f.write("map_cpu,label,xref_from,from_func\n")
    rm=currentProgram.getReferenceManager()
    for cpu,label in mapaddrs:
        for r in rm.getReferencesTo(A(cpu)):
            fa=r.getFromAddress()
            fn=fm.getFunctionContaining(fa)
            f.write("0x%06X,%s,0x%s,%s\n"%(cpu,label,fa,fn.getName() if fn else ""))

# summary
ninstr=listing.getNumInstructions()
with open(out+"/summary.txt","w") as f:
    f.write("instructions: %d\n"%ninstr)
    f.write("functions: %d\n"%cnt)
    f.write("labeled maps: %d\n"%labeled)
print("[post] instructions:",ninstr)
